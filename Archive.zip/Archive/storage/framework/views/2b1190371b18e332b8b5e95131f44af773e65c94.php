<?php $__env->startSection('content'); ?>
<div class="panel panel-default">
	<div class="panel-heading">Edit Item: <?php echo e($item->title); ?></div>

    <div class="panel-body">
    	<div class="col-lg-8">
    	
    	<?php echo Form::model($item, array('method' => 'PATCH', 'action' => ['ItemsController@update', $item->id] , 'files'=> true)); ?>

    	
    	<div class="form-group col-lg-4">
    		<?php echo Form::text('title', null, array('required', 'class'=>'form-control', 'placeholder' => 'Mneu Title')); ?>	
    	</div>
    	<div class="form-group col-lg-4">	
    		<?php echo Form::select('menu_id', $menus, null, array('required', 'class'=>'form-control', 'placeholder' => 'Choose Itme Menu')); ?>	
    	</div>
    	
    	<div class="form-group col-lg-4">	
    		<?php echo Form::select('status', ['1'=>'Active','0'=>'Inactive'], null, array('required', 'class'=>'form-control', 'placeholder' => 'Item Status')); ?>	
    	</div>
    	
    	<div class="form-group col-lg-12">	
    		<?php echo Form::textarea('description', null, array('required', 'class'=>'form-control', 'placeholder' => 'Item Description')); ?>	
    	</div>
    	<div class="form-group col-lg-4">
    		<?php echo Form::number('price', null, array('required', 'step' => 'any', 'class'=>'form-control', 'placeholder' => 'Item Price $')); ?>	
    	</div>
    	<div class="form-group col-lg-4">	
    		<?php echo Form::file('image', array('class'=>'form-control', 'placeholder' => 'Item Status')); ?>	
    	</div>
    	<div class="form-group col-lg-2">	
    		<?php echo Form::submit('Update', array('class'=>'btn btn-primary')); ?>	
    	</div>
    	<?php echo Form::close(); ?>

    		
    	</div>
    	
    	<div class="col-lg-4">
    		<img src="<?php echo e(asset($item->image)); ?>" alt="<?php echo e($item->title); ?>" class="img-responsive img-rounded editItemImg">	
    	</div>
    	
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>