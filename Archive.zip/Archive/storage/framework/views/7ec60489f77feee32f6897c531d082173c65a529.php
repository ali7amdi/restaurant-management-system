<?php $__env->startSection('content'); ?>
<div class="panel panel-default">
	<div class="panel-heading">Edit Meal: <?php echo e($meal->title); ?></div>

    <div class="panel-body">
    	<div class="col-lg-8">
    	
    	<?php echo Form::model($meal, array('method' => 'PATCH', 'action' => ['MealsController@update', $meal->id] , 'files'=> true)); ?>

    	
    	<div class="form-group col-lg-3">
    		<?php echo Form::text('title', null, array('required', 'class'=>'form-control', 'placeholder' => 'Mneu Title')); ?>	
    	</div>
    	
    	
    	<div class="form-group col-lg-3">	
    		<?php echo Form::select('status', ['1'=>'Active','0'=>'Inactive'], null, array('required', 'class'=>'form-control', 'placeholder' => 'Meal Status')); ?>	
    	</div>
    	
    	<div class="form-group col-lg-3">
    		<?php echo Form::number('price', null, array('required', 'step' => 'any', 'class'=>'form-control', 'placeholder' => 'Meal Price $')); ?>	
    	</div>
    	<div class="form-group col-lg-3">	
    		<?php echo Form::file('image', array('class'=>'form-control', 'placeholder' => 'Meal Status')); ?>	
    	</div>
    	
    	<div class="form-group col-lg-12">	
    		<?php echo Form::textarea('description', null, array('required', 'class'=>'form-control', 'placeholder' => 'Meal Description')); ?>	
    	</div>
    	
    	
    	</div>
    		
    	<div class="col-lg-4">
    		<img src="<?php echo e(asset($meal->image)); ?>" alt="<?php echo e($meal->title); ?>" class="img-responsive img-rounded editMealImg">	
    	</div>
    	
    	<div class="clearfix"></div>
    	
    	<div class="form-group">	
    		<?php foreach( $menus as $menu): ?>
    			<?php if(count($menu->items) > 0): ?>
	    			<h4><?php echo e($menu->title); ?></h4>
	    			<div class="form-group col-lg-6 menuItems">
	    			<ul>
	    				<?php foreach($menu->items as $item): ?>
			    			<li
			    			<?php if(in_array($item->id, $mealItemsIDs)): ?>
				    					class="red"
							<?php endif; ?>
							>
			    				<input 
				    				<?php if(in_array($item->id, $mealItemsIDs)): ?>
				    					checked
				    				<?php endif; ?>
			    					type="checkbox" 
			    					name="items[]" 
			    					value="<?php echo e($item->id); ?>"
			    				> 
			    				<input 
				    				<?php if(in_array($item->id, $mealItemsIDs)): ?>
				    					value="<?php echo e($mealItemsIDsWithDisocount[$item->id]); ?>"
				    				<?php endif; ?>
			    					type="number" 
			    					name="discount[<?php echo e($item->id); ?>]" 
			    					class="discount">
			    				<?php echo e($item->title); ?>

			    				
			    				
			    				</li>
		    			<?php endforeach; ?>	
	    			</ul>
	    			</div>
    			<?php endif; ?>	
    		<?php endforeach; ?>		
    	</div>
    	    	
    	<div class="clearfix"></div>    	
    	
    	<div class="form-group col-lg-2">	
    		<?php echo Form::submit('Update', array('class'=>'btn btn-primary')); ?>	
    	</div>
    	<?php echo Form::close(); ?>

    	
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>