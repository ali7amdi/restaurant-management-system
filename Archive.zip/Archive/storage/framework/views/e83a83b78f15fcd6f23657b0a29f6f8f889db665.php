<?php $__env->startSection('content'); ?>

<div class="panel panel-default">
   
    <div class="panel-heading">Items 
    	<a href="Items/create">
        	<span class="glyphicon glyphicon-plus pull-right"></span> 
    	</a>
    </div>

    <div class="panel-body">
		
		<table class="table table-bordered table-striped table-hover">
			<thead>
				<tr>
					<th>ID</th>
					<th>Title</th>
					<th>Price</th>
					<th>Description</th>
					<th>Status</th>
					<th>image</th>
					<th>Created By</th>
					<th>Menu</th>
					<th>Delete</th>
					<th>Edit</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach($items as $item): ?>
					<tr>
						<td><?php echo e($item->id); ?></td>
						<td><?php echo e($item->title); ?></td>
						<td><?php echo e($item->price); ?></td>
						<td><?php echo e($item->description); ?></td>
						<td><?php echo e($item->status); ?></td>
						<td class="menuThumb"> <img class="img-responsive" src="<?php echo e($item->image); ?>"></td>
						<td><?php echo e($item->user->name); ?></td>
						<td><?php echo e($item->menu->title); ?></td>
						<td>
				<?php echo Form::open(['method'=>'delete', 'route'=>['Items.destroy',$item->id]]); ?>

					<?php echo Form::submit('X', ['class'=>'btn btn-danger']); ?>

				<?php echo Form::close(); ?>

						</td>
						<td>	
							<a href="Items/<?php echo e($item->id); ?>/edit"> <span class="glyphicon glyphicon-edit"></span> </a>									
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
            
        <div class="paginatios col-lg-12">
        	<?php echo $items->links(); ?>

        </div>   
         
    </div>
</div>
       
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>