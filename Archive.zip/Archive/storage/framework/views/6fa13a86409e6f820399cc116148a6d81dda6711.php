<?php $__env->startSection('content'); ?>

<div class="panel panel-default">
   
    <div class="panel-heading">Meals 
    	<a href="Meals/create">
        	<span class="glyphicon glyphicon-plus pull-right"></span> 
    	</a>
    </div>

    <div class="panel-body">
		
		<table class="table table-bordered table-striped table-hover">
			<thead>
				<tr>
					<th>ID</th>
					<th>Title</th>
					<th>Description</th>
					<th>Price</th>
					<th>Status</th>
					<th>image</th>
					<th>Created By</th>
					<th>Delete</th>
					<th>Edit</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach($meals as $meal): ?>
					<tr>
						<td><?php echo e($meal->id); ?></td>
						<td><?php echo e($meal->title); ?></td>
						<td><?php echo e($meal->description); ?></td>
						<td><?php echo e($meal->price); ?></td>
						<td><?php echo e($meal->status); ?></td>
						<td class="menuThumb"> <img class="img-responsive" src="<?php echo e($meal->image); ?>"></td>
						<td><?php echo e($meal->user->name); ?></td>
						<td>
				<?php echo Form::open(['method'=>'delete', 'route'=>['Meals.destroy',$meal->id]]); ?>

					<?php echo Form::submit('X', ['class'=>'btn btn-danger']); ?>

				<?php echo Form::close(); ?>

						</td>
						<td>	
							<a href="Meals/<?php echo e($meal->id); ?>/edit"> <span class="glyphicon glyphicon-edit"></span> </a>									
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
            
        <div class="paginatios col-lg-12">
        	<?php echo $meals->links(); ?>

        </div>   
         
    </div>
</div>
       
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>