<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OrderMeal extends Model
{
    protected $table = 'order_meal';
}
